package sirin.render

import sirin.graphics.*
import sirin.graphics.text.NativeFont
import scala.collection.mutable.ArrayBuffer

final class PixelProgram private[render] (private[render] val words: Array[Float], val drawing: PreparedDrawing,
    val maskBytes: Long, val prepareNanos: Long):
  def uploadBytes: Long = words.length.toLong*4
  def readbackBytes: Long = ((drawing.target.width*4+255)& ~255).toLong*drawing.target.height

object PixelProgram:
  private enum Op:
    case Fill(path: FlatPath,color: PreparedPaint,rule: FillRule,clips: Vector[PreparedClip])
    case Quad(pixels: Vector[Color],width: Int,height: Int,source: Rect,dest: Rect,
      sampling: Sampling,alpha: Double,matrix: Affine,clips: Vector[PreparedClip])
    case Begin(alpha: Double)
    case End
  def compile(drawing: PreparedDrawing,maxOps: Int = 1024,maxVec4: Int = 2097152): PixelProgram =
    val began=System.nanoTime()
    require(maxOps>0 && maxOps<=4096 && maxVec4>0 && maxVec4<=4194304,"invalid program budgets")
    val faces=scala.collection.mutable.HashMap.empty[ResolvedFont,NativeFont]
    val masks=scala.collection.mutable.HashMap.empty[(ResolvedFont,Int,Double),GlyphRaster]
    var maskBytes=0L
    var sourcePixels=0L
    def claimPixels(w: Int,h: Int): Unit =
      sourcePixels+=w.toLong*h
      require(sourcePixels<=maxVec4,"expanded image pixel budget")
    val ops=ArrayBuffer.empty[Op]
    var sampleWork=0L
    def edgeCount(p: FlatPath): Long = p.contours.filter(_.size>1).map(_.size.toLong).sum
    def work(op: Op): Long = op match
      case Op.Fill(p,paint,_,clips) =>
        val stops=paint match
          case PreparedPaint.Solid(_) => 0
          case PreparedPaint.LinearGradient(_,_,_,s,_) => s.size
        1+edgeCount(p)+stops+clips.map(c => edgeCount(c.path)).sum
      case Op.Quad(_,_,_,_,_,_,_,_,clips) => 8+clips.map(c => edgeCount(c.path)).sum
      case _ => 1
    def append(op: Op): Unit =
      require(ops.size<maxOps,"expanded operation budget")
      sampleWork+=work(op)*drawing.target.width*drawing.target.height*16
      require(sampleWork<=500000000L,"per-sample work budget")
      ops+=op
    def pixels(image: ImageSnapshot): Vector[Color] =
      val b=image.pixelsCopy
      Vector.tabulate(image.width*image.height)(i => Color.rgba8(b(4*i)&255,b(4*i+1)&255,b(4*i+2)&255,b(4*i+3)&255))
    def density(m: Affine): Double =
      val s=Vector(m.a,m.b,m.c,m.d).map(math.abs).max
      if s==0 then 0 else
        val a=m.a/s;val b=m.b/s;val c=m.c/s;val d=m.d/s
        val tr=a*a+b*b+c*c+d*d;val det=a*d-b*c
        s*math.sqrt((tr+math.sqrt(math.max(0,tr*tr-4*det*det)))/2)
    try
      drawing.commands.foreach {
        case PreparedCommand.Fill(p,c,r,clips) => append(Op.Fill(p,c,r,clips))
        case PreparedCommand.BeginLayer(a) => append(Op.Begin(a))
        case PreparedCommand.EndLayer => append(Op.End)
        case PreparedCommand.Image(src,dest,sampling,alpha,m,clips) =>
          claimPixels(src.image.width,src.image.height)
          append(Op.Quad(pixels(src.image),src.image.width,src.image.height,src.source,dest,sampling,alpha,m,clips))
        case PreparedCommand.Glyphs(run,origin,color,m,clips) =>
          val scale=density(m)
          if scale>0 && m.inverse.nonEmpty then
            val face=faces.getOrElseUpdate(run.font,NativeFont.open(run.font.data,run.font.size,run.font.faceIndex))
            require(face.font.metrics==run.font.metrics && face.font.shaperVersion==run.font.shaperVersion &&
              face.font.rasterizerVersion==run.font.rasterizerVersion,"resolved font mismatch")
            run.glyphs.foreach { glyph =>
              val mask=masks.getOrElseUpdate((run.font,glyph.id,scale),{
                require(maskBytes<maxVec4,"mask byte budget")
                val r=face.rasterize(glyph.id,scale,maxPixels=(maxVec4-maskBytes).toInt);maskBytes+=r.byteSize
                require(maskBytes<=maxVec4.toLong,"mask byte budget");r
              })
              if mask.width>0 && mask.height>0 then
                claimPixels(mask.width,mask.height)
                val rgba=mask.coverageCopy.toVector.map(v => color.copy(alpha=color.alpha*(v&255)/255.0))
                val s=mask.deviceScale
                append(Op.Quad(rgba,mask.width,mask.height,Rect(0,0,mask.width,mask.height),
                  Rect(origin.x+glyph.position.x+mask.left/s,origin.y+glyph.position.y-mask.top/s,mask.width/s,mask.height/s),
                  Sampling.Linear,1,m,clips))
            }
      }
      val data=ArrayBuffer.fill[Float]((1+ops.size*8)*4)(0)
      def number(x: Double): Float = { val f=x.toFloat;require(f.isFinite,"nonfinite GPU value");f }
      def vector(v: Double*): Int =
        require(v.size==4 && data.size/4<maxVec4,"program storage budget")
        val index=data.size/4;data++=v.map(number);index
      def put(i: Int,v: Double*): Unit = v.zipWithIndex.foreach((x,j) => data(i*4+j)=number(x))
      def edges(path: FlatPath): (Int,Int) =
        val start=data.size/4
        path.contours.filter(_.size>1).foreach { contour =>
          contour.zip(contour.drop(1):+contour.head).foreach { (a,b) =>
            val values=Vector(a.x,a.y,b.x,b.y)
            require(values.forall(x => math.abs(number(x).toDouble-x)<=drawing.target.tolerance/8),"GPU coordinate precision")
            vector(a.x,a.y,b.x,b.y)
          }
        }
        (start,data.size/4-start)
      def clips(cs: Vector[PreparedClip]): (Int,Int) =
        val records=cs.map(c => {val (a,b)=edges(c.path);(a,b,c.rule.ordinal)})
        val start=data.size/4;records.foreach((a,b,c) => vector(a,b,c,0));(start,cs.size)
      def linear(x: Double): Double = if x<=0.04045 then x/12.92 else math.pow((x+0.055)/1.055,2.4)
      put(0,drawing.target.width,drawing.target.height,ops.size,0)
      ops.zipWithIndex.foreach { (op,i) =>
        val base=1+i*8
        op match
          case Op.Begin(a) => put(base,3,0,0,0);put(base+1,0,0,0,a)
          case Op.End => put(base,4,0,0,0)
          case Op.Fill(path,c,rule,cs) =>
            val (start,count)=edges(path);val (clipStart,clipCount)=clips(cs)
            put(base,1,start,count,rule.ordinal)
            c match
              case PreparedPaint.Solid(value) =>
                put(base+1,linear(value.red)*value.alpha,linear(value.green)*value.alpha,linear(value.blue)*value.alpha,value.alpha)
              case PreparedPaint.LinearGradient(x,y,offset,stops,extend) =>
                val anchor=path.contours.iterator.flatMap(_.headOption).nextOption().getOrElse(Point(0,0))
                val corners=Vector(Point(0,0),Point(drawing.target.width,0),Point(0,drawing.target.height),Point(drawing.target.width,drawing.target.height))
                require(corners.forall { p =>
                  val exact=(p.x-anchor.x)*x+(p.y-anchor.y)*y+offset
                  val packed=(p.x-number(anchor.x))*number(x)+(p.y-number(anchor.y))*number(y)+number(offset)
                  math.abs(exact-packed)<=1e-6
                },"gradient projection precision")
                val start=data.size/4
                stops.foreach { stop =>
                  val value=stop.color
                  vector(stop.offset,0,0,0)
                  vector(linear(value.red)*value.alpha,linear(value.green)*value.alpha,linear(value.blue)*value.alpha,value.alpha)
                }
                put(base+2,x,y,offset,extend.ordinal)
                put(base+3,start,stops.size,anchor.x,anchor.y)
                put(base+7,clipCount,1,0,0)
            put(base+6,0,0,0,clipStart);data((base+7)*4)=number(clipCount)
          case Op.Quad(rgba,w,h,src,dest,sampling,alpha,m,cs) =>
            val (clipStart,clipCount)=clips(cs)
            Vector(src.x,src.y,src.width,src.height,dest.x,dest.y,dest.width,dest.height).foreach { x =>
              require(math.abs(number(x).toDouble-x)<=drawing.target.tolerance/8,"texture rectangle precision")
            }
            m.inverse.filter(_ => dest.width>0 && dest.height>0).foreach { inv =>
              val approximate=Affine(inv.a.toFloat,inv.b.toFloat,inv.c.toFloat,inv.d.toFloat,inv.tx.toFloat,inv.ty.toFloat)
              val corners=Vector(Point(0,0),Point(drawing.target.width,0),Point(0,drawing.target.height),Point(drawing.target.width,drawing.target.height))
              require(corners.forall(p => math.hypot(inv(p).x-approximate(p).x,inv(p).y-approximate(p).y)<=1.0/128),"inverse texture precision")
              val start=data.size/4;rgba.foreach(c => vector(linear(c.red)*c.alpha,linear(c.green)*c.alpha,linear(c.blue)*c.alpha,c.alpha))
              put(base,2,0,0,0);put(base+2,inv.a,inv.c,inv.tx,alpha);put(base+3,inv.b,inv.d,inv.ty,sampling.ordinal)
              put(base+4,dest.x,dest.y,dest.width,dest.height);put(base+5,src.x,src.y,src.width,src.height)
              put(base+6,start,w,h,clipStart);put(base+7,clipCount,0,0,0)
            }
      }
      require(data.size/4<=maxVec4,"program storage budget")
      new PixelProgram(data.toArray,drawing,maskBytes,System.nanoTime()-began)
    finally faces.values.foreach(_.close())
