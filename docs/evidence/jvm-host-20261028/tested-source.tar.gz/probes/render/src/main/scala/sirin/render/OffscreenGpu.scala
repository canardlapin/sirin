package sirin.render

import sirin.graphics.*
import scala.scalanative.unsafe.*
import java.nio.file.{Files,Path as FilePath}

final class OffscreenGpu private(private var handle: Ptr[Byte],val generation: DeviceGeneration) extends AutoCloseable:
  private val owner=Thread.currentThread()
  private val retained=scala.collection.mutable.HashSet.empty[RetainedProgram]
  private def check(): Unit =
    require(Thread.currentThread() eq owner,"GPU owner thread mismatch")
    require(handle!=null,"GPU owner is closed")
  def target(width: Int,height: Int,scale: Double): RenderTarget =
    check();require(scale.isFinite && scale>0,"invalid device scale")
    RenderTarget(generation,width,height,Affine.scale(scale,scale))
  def render(program: PixelProgram,thorvg: Boolean = false): ImageSnapshot =
    check();require(program.drawing.target.device eq generation,"prepared drawing device generation mismatch")
    val t=program.drawing.target
    require(t.width.toLong*t.height<=1048576,"pixel budget")
    Zone.acquire { implicit zone =>
      val data=alloc[CFloat](program.words.length);program.words.indices.foreach(i => data(i)=program.words(i))
      val out=alloc[Byte](t.width*t.height*4)
      val status=GpuShim.sgpu_render(handle,data,program.words.length,t.width,t.height,if thorvg then 1 else 0,out)
      if status!=0 then throw new IllegalStateException(s"render status=$status: ${fromCString(GpuShim.sgpu_error(handle))}")
      ImageSnapshot.copyRgba8(t.width,t.height,Array.tabulate(t.width*t.height*4)(i => out(i)))
    }
  def resourceStats: GpuResourceStats =
    check()
    GpuResourceStats(GpuShim.sgpu_programs(handle),GpuShim.sgpu_retained_bytes(handle),GpuShim.sgpu_uploaded_bytes(handle))
  def retain(program: PixelProgram): RetainedProgram =
    check();require(program.drawing.target.device eq generation,"prepared drawing device generation mismatch")
    val t=program.drawing.target
    Zone.acquire { implicit zone =>
      val data=alloc[CFloat](program.words.length);program.words.indices.foreach(i => data(i)=program.words(i))
      val out=alloc[Ptr[Byte]]()
      val status=GpuShim.sgpu_retain(handle,data,program.words.length,t.width,t.height,out)
      if status!=0 then throw new IllegalStateException(s"retain status=$status: ${fromCString(GpuShim.sgpu_error(handle))}")
      val native= !out
      try
        val resource=new RetainedProgram(this,native,program)
        retained+=resource
        resource
      catch
        case error: Throwable => GpuShim.sgpu_program_close(native);throw error
    }
  private[render] def replay(resource: RetainedProgram): ImageSnapshot =
    check();require(retained(resource),"retained program is closed or belongs to another owner")
    val t=resource.program.drawing.target
    Zone.acquire { implicit zone =>
      val out=alloc[Byte](t.width*t.height*4)
      val status=GpuShim.sgpu_replay(resource.handle,out)
      if status!=0 then throw new IllegalStateException(s"replay status=$status: ${fromCString(GpuShim.sgpu_error(handle))}")
      ImageSnapshot.copyRgba8(t.width,t.height,Array.tabulate(t.width*t.height*4)(i => out(i)))
    }
  private[render] def retire(resource: RetainedProgram): Unit =
    require(Thread.currentThread() eq owner,"GPU owner thread mismatch")
    if retained.remove(resource) then
      GpuShim.sgpu_program_close(resource.handle)
      resource.clear()
  def close(): Unit =
    require(Thread.currentThread() eq owner,"GPU owner thread mismatch")
    if handle!=null then
      retained.toVector.foreach(retire)
      GpuShim.sgpu_close(handle);handle=null

/** Requested storage-buffer + output-texture payload, excluding driver overhead,
  * staging, pipeline and bind-group allocations. Uploads count direct storage.
  */
final case class GpuResourceStats(programs: Int, retainedBytes: Long, uploadedBytes: Long)

final class RetainedProgram private[render](private val owner: OffscreenGpu,
    private[render] var handle: Ptr[Byte], private[render] var program: PixelProgram) extends AutoCloseable:
  def render(): ImageSnapshot = owner.replay(this)
  def close(): Unit = owner.retire(this)
  private[render] def clear(): Unit =
    handle=null
    program=null

object OffscreenGpu:
  def liveOwners: Int = GpuShim.sgpu_live()
  def open(): OffscreenGpu = Zone.acquire { implicit zone =>
    val paths=Vector(FilePath.of("probes/render/src/main/resources/raster.wgsl"),FilePath.of("src/main/resources/raster.wgsl"))
    val shader=Files.readString(paths.find(Files.exists(_)).getOrElse(throw new IllegalStateException("missing shader")))
    val out=alloc[Ptr[Byte]]();val error=alloc[Byte](512)
    val status=GpuShim.sgpu_open(toCString(shader),out,error)
    if status!=0 then throw new IllegalStateException(s"GPU open: ${fromCString(error)}")
    val handle= !out
    try new OffscreenGpu(handle,new DeviceGeneration("wgpu-native-29.0.1.1/reference-v1",fromCString(GpuShim.sgpu_adapter(handle))))
    catch
      case error: Throwable => GpuShim.sgpu_close(handle);throw error
  }
@extern private[render] object GpuShim:
  @blocking def sgpu_open(shader: CString,out: Ptr[Ptr[Byte]],error: Ptr[Byte]): CInt = extern
  @blocking def sgpu_close(handle: Ptr[Byte]): Unit = extern
  @blocking def sgpu_render(handle: Ptr[Byte],data: Ptr[CFloat],count: CInt,width: CInt,height: CInt,thorvg: CInt,out: Ptr[Byte]): CInt = extern
  @blocking def sgpu_retain(handle: Ptr[Byte],data: Ptr[CFloat],count: CInt,width: CInt,height: CInt,out: Ptr[Ptr[Byte]]): CInt = extern
  @blocking def sgpu_replay(program: Ptr[Byte],out: Ptr[Byte]): CInt = extern
  @blocking def sgpu_program_close(program: Ptr[Byte]): Unit = extern
  def sgpu_programs(handle: Ptr[Byte]): CInt = extern
  def sgpu_retained_bytes(handle: Ptr[Byte]): CLongLong = extern
  def sgpu_uploaded_bytes(handle: Ptr[Byte]): CLongLong = extern
  def sgpu_adapter(handle: Ptr[Byte]): CString = extern
  def sgpu_error(handle: Ptr[Byte]): CString = extern
  def sgpu_live(): CInt = extern
