package sirin.graphics

import scala.collection.mutable.ArrayBuffer

/** Bounded path-space polyline stroke expansion. Every polygon has the same
  * winding, so one nonzero fill forms their union without alpha overdraw.
  * Curves require a separately qualified offset/tangent error bound.
  */
private[graphics] object StrokePreparation:
  def outline(path: Path, style: StrokeStyle, transform: Affine, tolerance: Double, maxPoints: Int): Path =
    val polygons = ArrayBuffer.empty[Vector[Point]]
    var work = 0
    var vertices = 0
    def step(): Unit =
      work += 1
      require(work <= maxPoints * 8L, "stroke work budget")
    def polygon(ps: Vector[Point]): Unit =
      vertices += ps.size + 2
      require(vertices <= maxPoints, "stroke point budget")
      val area = ps.zip(ps.drop(1) :+ ps.head).map((a,b) => (a.x-ps.head.x)*(b.y-ps.head.y)-(a.y-ps.head.y)*(b.x-ps.head.x)).sum
      require(area.isFinite, "stroke polygon overflow")
      if area != 0 then polygons += (if area > 0 then ps else ps.reverse)
    val radius = style.width/2
    // Frobenius norm bounds the largest affine singular value.
    val density = math.hypot(math.hypot(transform.a,transform.b),math.hypot(transform.c,transform.d))
    val deviceRadius = radius*density
    require(deviceRadius.isFinite, "stroke radius overflow")
    def plus(a: Point,b: Point): Point =
      val p=Point(a.x+b.x,a.y+b.y)
      require(math.hypot((p.x-a.x)-b.x,(p.y-a.y)-b.y)*density<=tolerance/8,"stroke coordinate precision")
      p
    def minus(a: Point,b: Point): Point = Point(a.x-b.x,a.y-b.y)
    def times(a: Point,s: Double): Point = Point(a.x*s,a.y*s)
    def cross(a: Point,b: Point): Double = a.x*b.y-a.y*b.x
    def disk(p: Point): Unit =
      val error = tolerance/2
      val angle = if deviceRadius <= error then math.Pi/2 else
        2*math.asin(math.sqrt(math.min(1,error/(2*deviceRadius))))
      val count = math.max(8,math.ceil(2*math.Pi/angle))
      require(count.isFinite && count <= maxPoints-vertices-2, "round stroke point budget")
      polygon(Vector.tabulate(count.toInt)(i => plus(p,Point(radius*math.cos(i*2*math.Pi/count),radius*math.sin(i*2*math.Pi/count)))))
    def cap(p: Point,u: Point,start: Boolean): Unit = style.cap match
      case LineCap.Butt => ()
      case LineCap.Round => disk(p)
      case LineCap.Square =>
        val n=Point(-u.y*radius,u.x*radius)
        val extension=times(u,if start then -radius else radius)
        polygon(Vector(plus(p,n),minus(p,n),plus(minus(p,n),extension),plus(plus(p,n),extension)))
    def stroke(raw: Vector[Point],closed: Boolean): Unit =
      step()
      val ps=raw.foldLeft(Vector.empty[Point])((v,p) => if v.lastOption.contains(p) then v else v:+p)
      if ps.size==1 then
        if raw.size>1 then style.cap match
          case LineCap.Round => disk(ps.head)
          case LineCap.Square =>
            val p=ps.head
            polygon(Vector(Point(p.x-radius,p.y-radius),Point(p.x+radius,p.y-radius),Point(p.x+radius,p.y+radius),Point(p.x-radius,p.y+radius)))
          case LineCap.Butt => ()
      else if ps.size>1 then
        val points=if closed && ps.head==ps.last then ps.dropRight(1) else ps
        val pairs=points.zip(if closed then points.drop(1):+points.head else points.drop(1))
        val units=pairs.map { (a,b) =>
          val v=minus(b,a);val length=math.hypot(v.x,v.y)
          require(length.isFinite && length>0, "stroke extent overflow")
          times(v,1/length)
        }
        pairs.zip(units).foreach { case ((a,b),u) =>
          step();val n=Point(-u.y*radius,u.x*radius)
          polygon(Vector(plus(a,n),minus(a,n),minus(b,n),plus(b,n)))
        }
        val joins=if closed then points.indices else 1 until points.size-1
        joins.foreach { i =>
          step()
          val u=units((i+units.size-1)%units.size);val v=units(i%units.size)
          val turn=cross(u,v);val p=points(i)
          if style.join==LineJoin.Round then disk(p)
          else if math.abs(turn)>1e-14 then
            val sign=if turn>0 then -1.0 else 1.0
            val a=plus(p,Point(-u.y*radius*sign,u.x*radius*sign))
            val b=plus(p,Point(-v.y*radius*sign,v.x*radius*sign))
            val hit=plus(a,times(u,cross(minus(b,a),v)/turn))
            val miter=math.hypot(hit.x-p.x,hit.y-p.y)/radius
            if style.join==LineJoin.Miter && miter<=style.miterLimit then polygon(Vector(p,a,hit,b))
            else polygon(Vector(p,a,b))
        }
        if !closed then {cap(points.head,units.head,true);cap(points.last,units.last,false)}
    val pattern=style.normalizedDashes
    def contour(raw: Vector[Point],closed: Boolean): Unit =
      if pattern.isEmpty then stroke(raw,closed)
      else if raw.nonEmpty then
        val ps=if closed && raw.last!=raw.head then raw:+raw.head else raw
        var index=0
        val remainder=style.dashOffset % pattern.sum
        var phase=if remainder<0 then remainder+pattern.sum else remainder
        while phase>0 && phase>=pattern(index) do
          step();phase-=pattern(index);index=(index+1)%pattern.size
        var remaining=pattern(index)-phase
        val fragments=ArrayBuffer.empty[Vector[Point]]
        val current=ArrayBuffer.empty[Point]
        def finish(): Unit =
          if current.nonEmpty then {fragments+=current.toVector;current.clear()}
        def advance(p: Point): Unit =
          while remaining==0 do
            step()
            if index%2==0 then
              if pattern(index)==0 then fragments+=Vector(p,p)
              finish()
            index=(index+1)%pattern.size;remaining=pattern(index)
        ps.zip(ps.drop(1)).foreach { (a,b) =>
          val length=math.hypot(b.x-a.x,b.y-a.y)
          require(length.isFinite,"dash extent overflow")
          var distance=0.0
          var p=a
          if length==0 then
            advance(a)
            if index%2==0 then {current+=a;current+=b}
          while distance<length do
            step();advance(p)
            val take=math.min(remaining,length-distance)
            val next=distance+take
            require(next>distance,"dash precision exhausted")
            val q=if next==length then b else Point(a.x+(b.x-a.x)*(next/length),a.y+(b.y-a.y)*(next/length))
            if index%2==0 then
              if current.isEmpty then current+=p
              current+=q
            distance=next;p=q;remaining=math.max(0,remaining-take)
            if remaining==0 then advance(p)
        }
        finish()
        // A dash that crosses the explicit close has a join at the seam.
        if closed && fragments.size>1 && fragments.head.head==ps.head && fragments.last.last==ps.head then
          val joined=fragments.last++fragments.head.drop(1)
          fragments.remove(fragments.size-1);fragments(0)=joined
        fragments.foreach(p => stroke(p,closed && p.size>1 && p.head==p.last))
    val line=ArrayBuffer.empty[Point]
    var start=Point(0,0)
    def finish(closed: Boolean): Unit =
      if line.nonEmpty then contour(line.toVector,closed)
      line.clear()
    path.segments.foreach { segment =>
      step()
      segment match
        case PathSegment.MoveTo(p) => finish(false);start=p;line+=p
        case PathSegment.LineTo(p) => line+=p
        case PathSegment.Close => finish(true);line+=start
        case _ => throw new IllegalArgumentException("curved stroke unsupported")
    }
    finish(false)
    Path(polygons.toVector.flatMap(p => Vector(PathSegment.MoveTo(p.head))++p.tail.map(PathSegment.LineTo.apply):+PathSegment.Close))
